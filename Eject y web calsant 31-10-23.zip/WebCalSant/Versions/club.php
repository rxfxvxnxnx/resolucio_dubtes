<!DOCTYPE html>
<html lang="en" data-theme="light">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link
      rel="shortcut icon"
      href="./assets/img/favicon.svg"
      type="image/x-icon" />
    <title>Club Cal Sant</title>

    <!-- CSS -->
    <link rel="stylesheet" href="./assets/css/pico-1.5.9/css/pico.min.css" />
    <link rel="stylesheet" href="./assets/css/style.css"/>

  </head>

  <body class="container" data-theme="dark">
    <!-- Header -->
    <nav >
        <ul>
            <li id="logo"><img src="./assets/img/logo-cal-sant.png" /></li>
        </ul>
        <ul>
          <li><a href="#" class="navBarMenu">Inici</a></li>
          <li><a href="#" class="navBarMenu">Fer una reserva</a></li>
          <li><a href="#" class="navBarMenu">Contacte </a></li>
          <li><a href="#" class="navBarMenu">Botiga</a></li>
          <li><a href="#" class="navBarMenu">Agenda cultural</a></li>
          <li><a href="#" class="navBarMenu">Club Cal Sant</a></li>
        </ul>
      </nav>

      <article class="articleClubCalSant" data-theme="dark">
        <h1>Benvinguts al Club Cal Sant</h1>

        <p>
            <span>Uneix-te al Club Cal Sant i gaudeix d'avantatges i descomptes exclusius.</span>
            <span>La nostra targeta de fidelització està disponible per a tots els clients de CalSant.</span>
            <span>recull la teva targeta sense <b>cap cost addicional</b>.</span>
        </p>
          
        <button class="joinInButton" data-target="unirSeClubCalSant" onClick="toggleModal(event)">Unir-se</button>
    </article>
      
    <p class="texto-con-lineas">Beneficis</p>

    <article class="articleClubCalSant" data-theme="dark">
        <div class="card-container">
            <div class="card">
                <div class="card-svg">
                    <img src="./assets/img/tag.png" alt="tagDisscountImg">

                </div>
                <div class="card-text">
                    <p>Descomptes en sopars</p>
                </div>
            </div>
    
            <div class="card">
                <div class="card-svg">
                    <img src="./assets/img/olives.png" alt="appetizersImg">
                </div>
                <div class="card-text">
                    <p>Descomptes en aperitius i cerveses</p>
                </div>
            </div>
    
            <div class="card">
                <div class="card-svg">
                    <img src="./assets/img/wine-bottle.png" alt="wineIMG">
                </div>
                <div class="card-text">
                    <p>Descomptes a la botiga de vins</p>
                </div>
            </div>

            <div class="card">
                <div class="card-svg">
                    <img src="./assets/img/tag.png" alt="tagDisscountImg">
                </div>
                <div class="card-text">
                    <p>Descomptes en la cistella ecològica de verdures</p>
                </div>
            </div>

            <div class="card">
                <div class="card-svg">
                    <img src="./assets/img/megaphone.png" alt="megaphoneImg">
                </div>
                <div class="card-text">
                    <p>Ser el primer en coneixer les nostres activitats</p>
                </div>
            </div>

            <div class="card">
                <div class="card-svg">
                    <img src="./assets/img/tag.png" alt="tagDisscountImg">
                </div>
                <div class="card-text">
                    <p>Descomptes especials a les activitats</p>
                </div>
            </div>
        </div>
    </article>
    
    <dialog id="unirSeClubCalSant">
        <article>
          <a href="#close" aria-label="Close" class="close" data-target="unirSeClubCalSant" onClick="toggleModal(event)"></a>
          <hgroup>
            <h1>Unir-se</h1>
            <h2>Introdueix les teves dades</h2>
          </hgroup>
          <form onsubmit="return validarFormulario()" id="unirSeClubCalSantForm" method="POST" action="club.php">
            <label for="nomCognoms">Nom i Cognoms
              <input type="text" name="user" placeholder="Nom i Cognoms" aria-label="User" autocomplete="nickname" aria-invalid="" required  value="test"/>
            </label>
            <label for="email">Email
              <input type="email" name="email" placeholder="Email" aria-label="email" autocomplete="email" aria-invalid="" required value="test@gmail.com" />
            </label>
            <label for="telefon">Telèfon
              <input type="text" name="telefon" placeholder="Telefon" aria-label="telefon" autocomplete="telefon" aria-invalid="" required  value="test"/>
            </label>
            <label for="dataNaixement">Data de Naixement
              <input type="date" name="dataNaixement" placeholder="yyyy-mm-dd" aria-label="dataNaixement" autocomplete="dataNaixement" aria-invalid="" required lang="en" />
            </label>
            <label for="poblacio">Població
              <input type="text" name="poblacio" placeholder="Població" aria-label="poblacio" autocomplete="poblacio" aria-invalid="" required  value="test"/>
            </label>
            <fieldset>
              <legend>Configuració de notificacions i termes</legend>
              <input type="checkbox" id="notificacions" name="notificacions" />
              <label for="notificacions">Desitjo rebre notificacions sobre els nous esdeveniments</label>
              <br>
              <input type="checkbox" id="acceptarTermes" name="acceptarTermes" required/>
              <label id="acceptarTermes" for="acceptarTermes">Acepto els termes i condicions <a href="#"> Veure els termes d'ús</a></label>
            </fieldset>
            <button id="inscribeCalSant" type="submit">Inscriure`t</button>
          </form>
        </article>
      </dialog>
     
     
      <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
      <script src="./assets/js/script.js"></script>  
    <script src="./assets/js/modal.js"></script>
</body>
</html>