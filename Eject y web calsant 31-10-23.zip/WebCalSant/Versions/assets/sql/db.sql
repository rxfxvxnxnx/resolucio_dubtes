CREATE DATABASE webcalsant;

-- Tabla de Miembros
CREATE TABLE Members (
    MemberId INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(255),
    Email VARCHAR(255),
    Phone VARCHAR(20),
    DateOfBirth DATE,
    City VARCHAR(100),
    ReceiveNotifications BOOLEAN,
    AcceptTermsAndConditions BOOLEAN
);

-- Tabla de Puntos Acumulados
CREATE TABLE MemberPoints (
    PointId INT AUTO_INCREMENT PRIMARY KEY,
    MemberId INT,
    Points INT,
    FOREIGN KEY (MemberId) REFERENCES Members(MemberId)
);

-- Tabla de Recompensas
CREATE TABLE Rewards (
    RewardId INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(255),
    Description TEXT,
    Type VARCHAR(50),
    Value DECIMAL(10, 2)
);

-- Tabla de Descuentos Nombrados
CREATE TABLE NamedDiscounts (
    NamedDiscountId INT AUTO_INCREMENT PRIMARY KEY,
    RewardId INT,
    Code VARCHAR(20),
    FOREIGN KEY (RewardId) REFERENCES Rewards(RewardId)
);

-- Tabla de Ofertas
CREATE TABLE Offers (
    OfferId INT AUTO_INCREMENT PRIMARY KEY,
    RewardId INT,
    Code VARCHAR(20),
    FOREIGN KEY (RewardId) REFERENCES Rewards(RewardId)
);
