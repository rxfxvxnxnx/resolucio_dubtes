document.addEventListener("DOMContentLoaded", function () {
  // Función para manejar el clic en el botón "Inscriure`t"
  document.getElementById("inscribeCalSant").addEventListener("click", function (event) {
      event.preventDefault(); // Esto evita que el formulario se envíe directamente

      // Realiza la verificación de campos aquí
      if (verificarCampos()) {
        // Si los campos son válidos, puedes enviar el formulario
        document.querySelector("form").submit();
      } else {
      }
    });

  // Función para verificar los campos del formulario
  function verificarCampos() {
    var campos = document.querySelectorAll("form input[required]");
    var camposValidos = true;

    campos.forEach(function (campo) {
      if (campo.value.trim() === "") {
        camposValidos = false;
        // Marcar campos no válidos agregando el atributo aria-invalid
        campo.setAttribute("aria-invalid", "true");
      } else {
        // Si el campo es válido, asegúrate de que no haya un atributo aria-invalid
        campo.removeAttribute("aria-invalid");
      }

      if (campo.type === "email" && !validarEmail(campo.value)) {
        camposValidos = false;
        campo.setAttribute("aria-invalid", "true");
      }

      if (campo.type === "checkbox" && !campo.checked) {
        camposValidos = false;
        campo.style.borderColor = "red";
      }
    });

    // Cambiar el color del texto a rojo para el elemento con ID "acceptarTermes"
    var acceptarTermes = document.getElementById("acceptarTermes");
    if (acceptarTermes) {
      acceptarTermes.style.color = "red";
    }

    return camposValidos;
  }

  // Función para validar el formato de correo electrónico
  function validarEmail(email) {
    var regex = /^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/;
    return regex.test(email);
  }

    console.log("DOMContentLoaded event fired.");
  
    document.getElementById("unirSeClubCalSantForm").addEventListener("submit", function(event) {
      console.log("Form submitted.");
        event.preventDefault(); // Evita el envío normal del formulario.
  
        var formData = new FormData(this);
  
        console.log("FormData created.");
  
        fetch("../../php/createUsersClub.php", {
          method: "POST",
          body: formData,
        })
          .then((response) => {
            console.log("Fetch response received.");
            return response.text();
          })
          .then((data) => {
            console.log("Data received from server:", data);
          })
          .catch((error) => {
            console.error("Error:", error);
          });
      });
    });
  
  

