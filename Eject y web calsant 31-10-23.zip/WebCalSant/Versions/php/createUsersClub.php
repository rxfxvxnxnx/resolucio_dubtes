<?php

require ('database.php');

echo "HE llegado aqui capullo";

$Name = $_POST['user'];
$Email = $_POST['email'];
$Phone = $_POST['telefon'];
$DateOfBirth = $_POST['dataNaixement'];
$City = $_POST['poblacio'];
$ReceiveNotifications = isset($_POST['notificacions']) ? 1 : 0; // 1 si está marcado, 0 si no
$AcceptTermsAndConditions = isset($_POST['acceptarTermes']) ? 1 : 0; // 1 si está marcado, 0 si no

// Paso 3: Insertar los datos en la tabla "Members"
$sql = "INSERT INTO members (Name, Email, Phone, DateOfBirth, City, ReceiveNotifications, AcceptTermsAndConditions)
        VALUES ('$Name', '$Email', '$Phone', '$DateOfBirth', '$City', '$ReceiveNotifications', '$AcceptTermsAndConditions')";

if ($con->query($sql) === TRUE) {
    echo "Registro exitoso"; // Puedes personalizar el mensaje de éxito
} else {
    echo "Error al registrar: " . $con->error; // Manejo de errores
}

// Cierra la conexión
$con->close();
?>