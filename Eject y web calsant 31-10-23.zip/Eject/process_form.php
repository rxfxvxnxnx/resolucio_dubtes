<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Conecta a tu base de datos. Reemplaza los valores de conexión con los tuyos.
    require('database.php');

    $comercialName = $_POST['comercialName'];
    $fiscalName = $_POST['fiscalName'];
    $email = $_POST['email'];
    $cif = $_POST['cif'];
    $tlf = $_POST['tlf'];
    $direction = $_POST['direction'];
    $poblation = $_POST['poblation'];
    $province = $_POST['province'];
    $zipCode = $_POST['zipCode'];

    $user = $email; // Supongo que el email se usa como usuario

    // Consulta SQL para verificar si el usuario ya existe
    $checkUserQuery = "SELECT * FROM users WHERE user = ?";
    $stmtCheck = $con->prepare($checkUserQuery);
    $stmtCheck->bind_param('s', $user);
    $stmtCheck->execute();
    $resultCheck = $stmtCheck->get_result();

    if ($resultCheck->num_rows > 0) {
        echo "El usuario ya existe. No se puede crear.";
    } else {
        // Si el usuario no existe, procede con la inserción de la empresa y el usuario.
        // Consulta SQL para insertar los datos de la empresa en la base de datos
        $sql = "INSERT INTO enterprises (comercialName, fiscalName, email, cif, tlf, direction, poblation, province, zipCode) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("sssssssss", $comercialName, $fiscalName, $email, $cif, $tlf, $direction, $poblation, $province, $zipCode);

        // Ejecutar la consulta
        if ($stmt->execute()) {
            // Obtiene el ID de la empresa recién creada
            $idEnterprise = $con->insert_id; // Id empresa creada recientemente
            echo "Datos de la empresa insertados con éxito. ID de empresa: " . $idEnterprise;

            if (isset($_POST['localCounter'])) {
                $numberLocal = $_POST['localCounter'];

                // Itera a través de los locales
                for ($i = 1; $i <= $numberLocal; $i++) {
                    $localName = $_POST['localName' . $i];
                    $localDirection = $_POST['localDirection' . $i];
                    $poblation = $_POST['poblation' . $i];
                    $province = $_POST['province' . $i];
                    $zipCode = $_POST['zipCode' . $i];

                    // Consulta SQL para insertar los datos del local en la base de datos, utilizando el ID de la empresa como clave foránea
                    $sqlLocal = "INSERT INTO locals (localName, localDirection, poblation, province, zipCode, idEnterpriseFK) VALUES (?, ?, ?, ?, ?, ?)";
                    $stmtLocal = $con->prepare($sqlLocal);
                    $stmtLocal->bind_param("sssssi", $localName, $localDirection, $poblation, $province, $zipCode, $idEnterprise);

                    // Ejecutar la consulta del local
                    if ($stmtLocal->execute()) {
                        echo "Datos del local " . $i . " insertados con éxito.";
                    } else {
                        echo "Error al insertar datos del local " . $i . ": " . $stmtLocal->error;
                    }
                    $stmtLocal->close();
                }
            } else {
                echo "Error al insertar el local no se recibe 'localCounter'";
            }

            // Creación de usuario de la empresa
            $userPassword = password_hash($cif, PASSWORD_DEFAULT); // Hash del CIF como contraseña
            $activation = 0; // Valor para la columna "activation"
            $sqlUser = "INSERT INTO users (user, password, activation) VALUES (?, ?, ?)";
            $stmtUser = $con->prepare($sqlUser);
            $stmtUser->bind_param("ssi", $email, $userPassword, $activation);

            // Ejecutar la consulta para crear un usuario
            if ($stmtUser->execute()) {
                $idUser = $con->insert_id; // Obtén el ID del último usuario creado
                echo "Usuario creado con éxito para la empresa con ID: " . $idEnterprise;

                // Creación de detalles del usuario
                $sqlUserDetails = "INSERT INTO userdetails (idUserFK, idEnterpriseFK) VALUES (?, ?)";
                $stmtUserDetails = $con->prepare($sqlUserDetails);
                $stmtUserDetails->bind_param("ii", $idUser, $idEnterprise);

                // Ejecutar la consulta para crear detalles del usuario
                if ($stmtUserDetails->execute()) {
                    echo "Detalles del usuario creados con éxito.";
                } else {
                    echo "Error al crear detalles del usuario: " . $stmtUserDetails->error;
                }

            } else {
                echo "Error al crear el usuario: " . $stmtUser->error;
            }
            $stmtUser->close();
        } else {
            echo "Error al insertar datos de la empresa: " . $stmt->error;
        }

        // Cierra la consulta de verificación del usuario
        $stmtCheck->close();

        $con->close();
    }
}

?>
