<?php
require('./database.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_POST['user']) && !empty($_POST['password'])) {
        echo "Hasta aquí 1<br>";
        $user = $_POST['user'];
        $password = $_POST['password'];
        echo "Usuario: " . $user . "<br>";
        echo "Contraseña: " . $password . "<br>";

        // Consulta SQL para obtener los datos del usuario
        $query = "SELECT * FROM users WHERE user = ?";
        if ($stmt = $con->prepare($query)) {
            $stmt->bind_param('s', $user);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows == 1) {
                echo "Hasta aquí sí, hay 1 registro<br>";
            }

            if ($result->num_rows === 1) {
                echo "Hasta aquí 2, hay 1 registro<br>";
                $row = $result->fetch_assoc();
                $hashedPassword = $row['password'];

                // Verificar la contraseña con password_verify utilizando el hash almacenado
                if (password_verify($password, $hashedPassword)) {
                    echo "Contraseña válida, usuario autenticado<br>";
                    // Contraseña válida, usuario autenticado
                    // Después de verificar que el usuario existe
                    $activation = $row['activation'];
                    $ejectPrivileges = $row['ejectPrivileges'];

                    // Verifica el valor de activation y ejectPrivileges
                    if ($activation == 0) {
                        header("Location: ./pendienteDeActivacion.php");
                        exit; // Detiene la ejecución después de la redirección
                    } elseif ($activation == 1 && $ejectPrivileges === 1) {
                        header("Location: ./php/eject.php");
                        exit; // Detiene la ejecución después de la redirección
                    } elseif ($activation == 1 && !$ejectPrivileges) {
                        header("Location: ./php/clients.php");
                        exit; // Detiene la ejecución después de la redirección
                    }
                } else {
                    echo "Contraseña incorrecta<br>";
                }
            } else {
                echo "No se encontró al usuario<br>";
            }

            $stmt->close();
        } else {
            echo "Error en la consulta: " . $con->error . "<br>";
        }
    } else {
        echo "Por favor, ingrese el usuario y la contraseña.<br>";
    }
}
?>

<!DOCTYPE html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="shortcut icon" href="./assets/img/favicon.svg" type="image/x-icon">
        <title>Eject Computer</title>

        <!-- CSS -->
        <link rel="stylesheet" href="./assets/css/pico-1.5.9/css/pico.min.css">
        <link rel="stylesheet" href="./assets/css/style.css">
    </head>

    <body class="container">
        <!-- Header -->
        <nav class="container">

            <ul>
                <li id="logo"><img src="./assets/img/logo.svg"></li>
            </ul>
            <ul>
                <li><a href="#" class="secondary contrast" data-target="login" onClick="toggleModal(event)"><img src="./assets/img/user.svg"></a></li>
            </ul>
        </nav>

        <!-- Body -->
        <!-- Formulario Cliente Nuevo -->
        <article>
            <form action="process_form.php" method="POST" id="form2">
                <progress value="25" max="100" id="progresClient"></progress>

                <!-- Pestaña 0 -->
                <div class="tab-content" id="tab0" data-tab-id="tab0">

                    <h1 class="tittleForm">Formulario Clientes Nuevos</h1>

                    <div class="threePoints">. . .</div>

                    <button type="button" class="tab-button" onclick="showTab(1)" data-id-tab="0">Comenzar</button>
                </div>

                <!-- Pestaña 1 -->
                <div class="tab-content" id="tab1" style="display: none;" data-tab-id="1">

                    <h1>Datos Fiscales</h1>

                    <div class="grid">
                        <label for="comercialName">Nombre Comercial
                            <input type="text" id="comercialName" name="comercialName" placeholder="Nombre Comercial" required>
                        </label>
                        <label for="fiscalName">Nombre Fiscal
                            <input type="text" id="fiscalName" name="fiscalName" placeholder="Nombre Fiscal" required>
                        </label>
                    </div>
                    <div class="grid">
                        <label for="cif">CIF
                            <input type="text" id="cif" name="cif" placeholder="CIF" required>
                        </label>
                        <label for="tlf">Teléfono
                            <input type="text" id="tlf" name="tlf" placeholder="Teléfono" required>
                        </label>
                    </div>
                    <label for="email">Email de Facturación
                        <input type="email" id="email" name="email" placeholder="Email" required>
                    </label>

                    <div class="threePoints">. . .</div>

                    <div class="grid-row twoButtons">
                        <button type="button" class="tab-button" onclick="showTab(0)" id="prevButton">Anterior</button>
                        <button type="button" class="tab-button" onclick="showTab(2)" id="nextButton">Siguiente</button>
                    </div>

                </div>

                <!-- Pestaña 2 -->
                <div class="tab-content" id="tab2" style="display: none;">

                    <h1>Dirección Facturación</h1>

                    <label for="direction">Dirección
                        <input type="text" id="direction" name="direction" placeholder="Dirección" required>
                    </label>
                    <div class="grid">
                        <label for="poblation">Población
                            <input type="text" id="poblation" name="poblation" placeholder="Población" required>
                        </label>
                        <label for="province">Provincia
                            <input type="text" id="province" name="province" placeholder="Provincia" required>
                        </label>
                        <label for="zipCode">Codigo Postal
                            <input type="number" id="zipCode" name="zipCode" placeholder="Codigo Postal" required>
                        </label>
                    </div>

                    <div class="threePoints">. . .</div>

                    <div class="grid-row twoButtons">
                        <button type="button" class="tab-button" onclick="showTab(1)" id="prevButton">Anterior</button>
                        <button type="button" class="tab-button" onclick="showTab(3)" id="nextButton">Siguiente</button>
                    </div>
                </div>

                <!-- Pestaña 3 -->
                <div class="tab-content" id="tab3" style="display: none;">

                    <h1 id="localesTitulo">Locales</h1>

                    <div id="localesContainer"></div>

                    <div class="threePoints">. . .</div>

                    <input type="hidden" name="localCounter" id="localCounter" value="">

                    <div class="grid-row twoButtons">
                        <button type="button" class="tab-button" onclick="showTab(2)">Anterior</button>
                        <button type="submit">Enviar</button>
                    </div>
                </div>
            </form>
        </article>

        <!-- Footer -->
        <footer id="footer">
            <p>Made by Eject Computer Solucions Informatiques S.L. © <?php $year = date("Y");
                                                                        echo $year; ?>
            </p>
        </footer>

        <!-- Login -->
        <dialog id="login">
            <article>
                <a href="#close" aria-label="Close" class="close" data-target="login" onClick="toggleModal(event)">
                </a>
                <hgroup>
                    <h1>Login</h1>
                    <h2>Si es tu primera vez entra con tu Email y CIF</h2>
                </hgroup>
                <form method="POST" action="index.php">
                    <input type="text" name="user" placeholder="Usuario" aria-label="User" autocomplete="nickname" value="sateject@eject.com" required />
                    <input type="password" name="password" placeholder="Contraseña" aria-label="Password" autocomplete="current-password" value="sateject" required />
                    <fieldset>
                        <label for="remember">
                            <input type="checkbox" role="switch" id="remember" name="remember" />
                            Recuerdame
                        </label>
                    </fieldset>
                    <button type="submit" id="submitLogin">Login</button>
                </form>
            </article>
        </dialog>

        <script src="./assets/js/modal.js"></script>
        <script src="./assets/js/script.js"></script>
    </body>
</html>