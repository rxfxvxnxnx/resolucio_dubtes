if (window.location.href === "http://localhost/EJECT/index.php" || window.location.href === "http://localhost/EJECT/") {
  //Slid de las pestañas
  function showTab(tabNumber) {
    var i;
    var tabContents = document.getElementsByClassName("tab-content");
    var tabButtons = document.getElementsByClassName("tab-button");

    for (i = 0; i < tabContents.length; i++) {
      tabContents[i].style.display = "none";
    }

    for (i = 0; i < tabButtons.length; i++) {
      tabButtons[i].classList.remove("active");
    }

    document.getElementById("tab" + tabNumber).style.display = "block";
    event.currentTarget.classList.add("active");

    // Actualizar el valor de la barra de progreso gradualmente
    var progressElement = document.getElementById("progresClient");
    var currentProgress = progressElement.value;
    var targetProgress = (tabNumber + 1) * 25;
    var step = targetProgress - currentProgress > 0 ? 1 : -1; // Determinar si el progreso debe aumentar o disminuir
    var progressInterval = setInterval(function () {
      if (currentProgress !== targetProgress) {
        currentProgress += step;
        progressElement.value = currentProgress;
      } else {
        clearInterval(progressInterval);
      }
    }, 20); // Ajusta este valor para controlar la velocidad de la animación; un valor menor lo hará más rápido y un valor mayor lo hará más lento
  }

  //Crear Locales
  document.addEventListener("DOMContentLoaded", function () {
    const localCounterPHP = document.getElementById("localCounter");
    let localCounter = 0;

    function updateButtons() {
      const allAddButtons = document.querySelectorAll(".add-local");
      const allDeleteButtons = document.querySelectorAll(".delete-local");

      // Remover todos los botones actuales
      allAddButtons.forEach((btn) => btn.remove());
      allDeleteButtons.forEach((btn) => btn.remove());

      // Si hay al menos un "Local", agregar botón de añadir al último "Local"
      if (localCounter >= 1) {
        const lastLocal = document.getElementById("local" + localCounter);
        const addButton = document.createElement("img");
        addButton.src = "./assets/img/plus.svg";
        addButton.classList.add("add-local");
        addButton.addEventListener("click", addLocal);
        lastLocal.appendChild(addButton);

        // Si hay más de un "Local", agregar botón de eliminar al último "Local"
        if (localCounter > 1) {
          const deleteButton = document.createElement("img");
          deleteButton.src = "./assets/img/minus.svg";
          deleteButton.classList.add("delete-local");
          deleteButton.addEventListener("click", function () {
            document.getElementById("local" + localCounter).remove();
            localCounter--;
            localCounterPHP.value = localCounter;
            updateButtons();
          });
          lastLocal.appendChild(deleteButton);
        }
      }
    }

    function addLocal() {
      localCounter++;
      localCounterPHP.value = localCounter;

      const newLocalHTML = `
            <article id="local${localCounter}">
                <h5>Local ${localCounter}</h5>
                <div class="grid">
                    <label for="localName${localCounter}">Nombre del Local
                        <input type="text" name="localName${localCounter}" id="localName${localCounter}" placeholder="Nombre del Local" required>
                    </label>
                    <label for="localDirection${localCounter}">Direccion
                        <input type="text" name="localDirection${localCounter}" id="localDirection${localCounter}" placeholder="Direccion" required>
                    </label>
                </div>
                <div class="grid">
                    <label for="poblation${localCounter}">Población
                        <input type="text" id="poblation${localCounter}" name="poblation${localCounter}" placeholder="Población" required>
                    </label>
                    <label for="province${localCounter}">Provincia
                        <input type="text" id="province${localCounter}" name="province${localCounter}" placeholder="Provincia" required>
                    </label>
                    <label for="zipCode${localCounter}">Codigo Postal
                        <input type="number" id="zipCode${localCounter}" name="zipCode${localCounter}" placeholder="Codigo Postal" required>
                    </label>
                </div>
                <img src="./assets/img/plus.svg" class="add-local">
                ${
                  localCounter > 1
                    ? '<img src="./assets/img/minus.svg" class="delete-local">'
                    : ""
                }
            </article>
        `;

      document
        .getElementById("localesContainer")
        .insertAdjacentHTML("beforeend", newLocalHTML);
      updateButtons();
    }

    addLocal();
  
    })


  //Funcion enviar datos de la creacion de los nuevos clientes
  document.getElementById("form2").addEventListener("submit", function (event) {
    event.preventDefault(); // Evita el envío normal del formulario
    var formData = new FormData(this);

    fetch("process_form.php", {
      method: "POST",
      body: formData,
    })
      .then((response) => response.text())
      .then((data) => {
        // Maneja la respuesta del servidor, por ejemplo, muestra un mensaje de éxito o error.
        console.log(data);
        console.log("Numero de locales = ".localCounter);
        // Puedes redirigir al usuario a una página de agradecimiento o hacer otras acciones aquí.
      })
      .catch((error) => {
        // Maneja errores, por ejemplo, muestra un mensaje de error.
        console.error("Error:", error);
      });
  });

  const loginForm = document.getElementById("login");
const submitLogin = document.getElementById("submitLogin");

submitLogin.addEventListener("click", function () {
    const user = document.getElementById("user").value;
    const password = document.getElementById("password").value;

    // Realiza la solicitud AJAX para iniciar sesión
    $.ajax({
        url: "../../index.php",
        type: "POST",
        data: {
            user: user,
            password: password
        },
        success: function (response) {
          console.log("Correcdte");
        },
        error: function (error) {
          console.log("Incorrecte")
          // Maneja errores, si los hay
        }
    });
});
}


if (window.location.href === "http://localhost/EJECT/php/eject.php"){
//localhost/EJECT/php/client.php
// Cargar los resultados iniciales al cargar la página
$(document).ready(function () {
    $.ajax({
        url: "../php/clientdiv.php",
        type: "POST",
        data: { search: "" }, // Sin término de búsqueda
        success: function (data) {
            $("#clientsContainer").html(data); // Actualiza #clientsContainer con todos los resultados
        },
    });
});

//Funcion para el buscador
  $(document).ready(function () {
    var $searchForm = $("#searchForm"); // Selecciona el formulario por su ID
    var $searchInput = $("#searchInput");
    var $clientsContainer = $("#clientsContainer");

    // Prevenir el envío del formulario
    $searchForm.on("submit", function (e) {
      e.preventDefault();
    });

// Manejar la búsqueda en tiempo real en el evento 'input'
$searchInput.on("input", function () {
    var searchTerm = $searchInput.val();

    // Realiza una solicitud Ajax en vivo para buscar clientes
    $.ajax({
        url: "../php/clientdiv.php",
        type: "POST",
        data: { search: searchTerm },
        success: function (data) {
            // Actualiza el contenido de clientsContainer con los resultados en vivo
            $clientsContainer.html(data); // Aquí actualiza solo #clientsContainer    
            console.log(data);
        },
    });
});
})
}


