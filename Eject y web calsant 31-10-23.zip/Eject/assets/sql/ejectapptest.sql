-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 31-10-2023 a las 11:41:02
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ejectapptest`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contacts`
--

CREATE TABLE `contacts` (
  `idContact` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `typeFK` int(11) DEFAULT NULL,
  `idEnterpriseFK` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contactstype`
--

CREATE TABLE `contactstype` (
  `idContactType` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `enterprises`
--

CREATE TABLE `enterprises` (
  `idEnterprise` int(11) NOT NULL,
  `comercialName` varchar(50) DEFAULT NULL,
  `fiscalName` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `cif` varchar(50) DEFAULT NULL,
  `tlf` varchar(20) DEFAULT NULL,
  `direction` varchar(255) DEFAULT NULL,
  `poblation` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `zipCode` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `enterprises`
--

INSERT INTO `enterprises` (`idEnterprise`, `comercialName`, `fiscalName`, `email`, `cif`, `tlf`, `direction`, `poblation`, `province`, `zipCode`) VALUES
(1, 'ABC Comunicaciones', 'ABC Comunicaciones S.A.', 'info@abc-comunicaciones.com', 'B12345678', '123-456-789', ' Calle Principal, 123', 'Ciudad Principal', 'Provincia Uno', 12345),
(2, 'Comercial: XYZ Soluciones', 'XYZ Soluciones S.L.', 'info@xyz-soluciones.com', 'A98765432', '987-654-321', 'Avenida Central, 456', 'Ciudad Secundaria', ' Provincia Dos', 54321),
(3, 'InnovateTech', 'InnovateTech Solutions', 'contact@innovatetech-solutions.com', 'C55443322', '554-433-221', ' Calle Innovación, 67', 'Ciudad Innovadora', 'Provincia Tres', 33333),
(4, 'EcoRecycle', 'EcoRecycle S.L.', 'support@ecorecycle.com', 'E11223344', '112-233-445', 'Avenida Ecológica, 88', 'Ciudad Sostenible', 'Provincia Cuatro', 44444),
(5, 'HealthyBites', 'HealthyBites Foods', 'info@healthybites-foods.com', 'H99887766', '998-877-665', 'Calle Saludable, 12', 'Ciudad Salud', 'Provincia Cinco', 55555),
(6, 'sateject', 'sateject', 'sateject@eject.com', 'sateject', 'sateject', 'sateject', 'sateject', 'sateject', 8292);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `locals`
--

CREATE TABLE `locals` (
  `idLocals` int(11) NOT NULL,
  `localName` varchar(255) DEFAULT NULL,
  `localDirection` varchar(255) DEFAULT NULL,
  `poblation` varchar(255) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  `zipCode` varchar(255) DEFAULT NULL,
  `idEnterpriseFK` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `locals`
--

INSERT INTO `locals` (`idLocals`, `localName`, `localDirection`, `poblation`, `province`, `zipCode`, `idEnterpriseFK`) VALUES
(1, 'Local1', 'Dir1', 'Pob1', 'Prov1', '08292', 1),
(2, 'Lo', 'l', 'l', 'l', '23', 2),
(3, 'iop', 'oil', 'ji', 'oj', '2342', 3),
(4, 'sdads', 'ds', 'dd', 'sdfasf', '54584', 4),
(5, 'sdsad', 'bhijb', 'jh', 'h', '4545', 5),
(6, 'sateject', 'sateject', 'sateject', 'sateject', '08292', 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `userprivileges`
--

CREATE TABLE `userprivileges` (
  `idUserPrivileges` int(11) NOT NULL,
  `privilege` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `idUser` int(11) NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `ejectPrivileges` tinyint(1) DEFAULT NULL,
  `SmartphonePassword` varchar(255) DEFAULT NULL,
  `WebAdminPassword` varchar(255) DEFAULT NULL,
  `ButtonText` varchar(255) DEFAULT NULL,
  `Color` varchar(255) DEFAULT NULL,
  `CardNumber` varchar(255) DEFAULT NULL,
  `IsTrainee` tinyint(1) DEFAULT NULL,
  `Profile` int(11) DEFAULT NULL,
  `ShowInClockings` tinyint(1) DEFAULT NULL,
  `DeletionDate` date DEFAULT NULL,
  `SocialSecurityNumber` varchar(255) DEFAULT NULL,
  `Nif` int(11) DEFAULT NULL,
  `Telephone` int(11) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Street` varchar(255) DEFAULT NULL,
  `City` varchar(255) DEFAULT NULL,
  `Region` varchar(255) DEFAULT NULL,
  `ZipCode` int(11) DEFAULT NULL,
  `FullName` varchar(255) DEFAULT NULL,
  `CompanyName` varchar(255) DEFAULT NULL,
  `CompanyCif` varchar(255) DEFAULT NULL,
  `CompanyCCC` varchar(255) DEFAULT NULL,
  `AutoClockOutMaxHours` int(11) DEFAULT NULL,
  `activation` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`idUser`, `user`, `password`, `ejectPrivileges`, `SmartphonePassword`, `WebAdminPassword`, `ButtonText`, `Color`, `CardNumber`, `IsTrainee`, `Profile`, `ShowInClockings`, `DeletionDate`, `SocialSecurityNumber`, `Nif`, `Telephone`, `Email`, `Street`, `City`, `Region`, `ZipCode`, `FullName`, `CompanyName`, `CompanyCif`, `CompanyCCC`, `AutoClockOutMaxHours`, `activation`) VALUES
(1, 'info@abc-comunicaciones.com', '$2y$10$moRHZlAKGSquqYkY/63VSug9548Dq31L.ObGgQnFT7tdv1UAg0Tbu', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(2, 'info@xyz-soluciones.com', '$2y$10$F7TfEirHNpH7SwTrTsOvu.77VrBmx9RIjdzD.gBHOo/g8ycmCJdfa', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(3, 'contact@innovatetech-solutions.com', '$2y$10$XwLAiDrfAJu7WlIv8zfYp.H28t2UeSPnxTjPMf9k.pl58s2/kxlLS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(4, 'support@ecorecycle.com', '$2y$10$ko9z8x2dOhpj.t3GQ..aeeW9kLOUCAfOEHl0tv5RT.ngg6RPUwWby', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(5, 'info@healthybites-foods.com', '$2y$10$We/7/bPynpd3UCRvlpdv8eITKhgoLVuacXcllqL6nNYzud1gHl4qC', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(6, 'sateject@eject.com', '$2y$10$DwRcBUiDq.WJU09/wFKVM.SRnZXN6AETCPo0f3Joi1kou2kYn6UiG', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`idContact`),
  ADD KEY `typeFK` (`typeFK`),
  ADD KEY `idEnterpriseFK` (`idEnterpriseFK`);

--
-- Indices de la tabla `contactstype`
--
ALTER TABLE `contactstype`
  ADD PRIMARY KEY (`idContactType`);

--
-- Indices de la tabla `enterprises`
--
ALTER TABLE `enterprises`
  ADD PRIMARY KEY (`idEnterprise`);

--
-- Indices de la tabla `locals`
--
ALTER TABLE `locals`
  ADD PRIMARY KEY (`idLocals`),
  ADD KEY `idEnterpriseFK` (`idEnterpriseFK`);

--
-- Indices de la tabla `userprivileges`
--
ALTER TABLE `userprivileges`
  ADD PRIMARY KEY (`idUserPrivileges`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`idUser`),
  ADD KEY `Profile` (`Profile`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `contacts`
--
ALTER TABLE `contacts`
  MODIFY `idContact` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `contactstype`
--
ALTER TABLE `contactstype`
  MODIFY `idContactType` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `enterprises`
--
ALTER TABLE `enterprises`
  MODIFY `idEnterprise` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `locals`
--
ALTER TABLE `locals`
  MODIFY `idLocals` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `userprivileges`
--
ALTER TABLE `userprivileges`
  MODIFY `idUserPrivileges` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `contacts`
--
ALTER TABLE `contacts`
  ADD CONSTRAINT `contacts_ibfk_1` FOREIGN KEY (`typeFK`) REFERENCES `contactstype` (`idContactType`),
  ADD CONSTRAINT `contacts_ibfk_2` FOREIGN KEY (`idEnterpriseFK`) REFERENCES `enterprises` (`idEnterprise`);

--
-- Filtros para la tabla `locals`
--
ALTER TABLE `locals`
  ADD CONSTRAINT `locals_ibfk_1` FOREIGN KEY (`idEnterpriseFK`) REFERENCES `enterprises` (`idEnterprise`);

--
-- Filtros para la tabla `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`Profile`) REFERENCES `userprivileges` (`idUserPrivileges`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
