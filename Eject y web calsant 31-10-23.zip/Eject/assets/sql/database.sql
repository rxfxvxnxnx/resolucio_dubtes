CREATE DATABASE IF NOT EXISTS ejectapptest;

USE ejectapptest;

CREATE TABLE enterprises (
    idEnterprise INT PRIMARY KEY AUTO_INCREMENT,
    comercialName VARCHAR(50),
    fiscalName VARCHAR(50),
    email VARCHAR(255),
    cif VARCHAR(50),
    tlf VARCHAR(20),
    direction VARCHAR(255),
    poblation VARCHAR(100),
    province VARCHAR(100),
    zipCode INT 
);

CREATE TABLE locals (
    idLocals INT PRIMARY KEY AUTO_INCREMENT,
    localName VARCHAR(255),
    localDirection VARCHAR(255),
    poblation VARCHAR(255),
    province VARCHAR(255),
    zipCode VARCHAR(255),

    idEnterpriseFK INT, 
    FOREIGN KEY (idEnterpriseFK) REFERENCES enterprises(idEnterprise)
);

CREATE TABLE contactsType (
    idContactType INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR (255)
);

CREATE TABLE contacts (
    idContact INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100),
    lastName VARCHAR(100),
    email VARCHAR(255),

    typeFK INT,
    FOREIGN KEY (typeFK) REFERENCES contactsType(idContactType),

    idEnterpriseFK INT, 
    FOREIGN KEY (idEnterpriseFK) REFERENCES enterprises(idEnterprise)
);

CREATE TABLE userPrivileges (
    idUserPrivileges INT PRIMARY KEY AUTO_INCREMENT,
    privilege VARCHAR(255)
);

CREATE TABLE users (
    idUser INT PRIMARY KEY AUTO_INCREMENT,
    user VARCHAR(255),
    password VARCHAR(255),
    ejectPrivileges BOOLEAN,
    SmartphonePassword VARCHAR(255),
    WebAdminPassword VARCHAR(255),
    ButtonText VARCHAR(255),
    Color VARCHAR(255),
    CardNumber VARCHAR(255),
    IsTrainee BOOLEAN,
    Profile INT,
    FOREIGN KEY (Profile) REFERENCES userPrivileges(idUserPrivileges),
    ShowInClockings BOOLEAN,
    DeletionDate DATE,
    SocialSecurityNumber VARCHAR(255),
    Nif INT,
    Telephone INT,
    Email VARCHAR(255),
    Street VARCHAR(255),
    City VARCHAR(255),
    Region  VARCHAR(255),
    ZipCode INT,
    FullName VARCHAR(255),
    CompanyName VARCHAR(255),
    CompanyCif VARCHAR(255),
    CompanyCCC VARCHAR(255),
    AutoClockOutMaxHours INT,
    activation BOOLEAN
);

CREATE TABLE userDetails (
    idUserFK INT PRIMARY KEY,
    FOREIGN KEY (idUserFK) REFERENCES users(idUser),

    idEnterpriseFK INT, 
    FOREIGN KEY (idEnterpriseFK) REFERENCES enterprises(idEnterprise)
);

