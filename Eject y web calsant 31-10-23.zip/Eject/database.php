<?php
    $host = "localhost";
    $database = "ejectapptest";
    $usuario = "test";
    $contraseña = "test";
        
    $con = mysqli_connect($host,$usuario,$contraseña,$database)or exit (mysqli_connect_error());
?>