<!DOCTYPE html>
<html lang="en" data-theme="light">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="shortcut icon" href="../assets/img/favicon.svg" type="image/x-icon">
    <title>Eject Computer</title>

    <!-- Importacion Jquery buscador -->
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/pico-1.5.9/css/pico.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="container">
    <!-- Header -->
    <nav class="container">
        <ul>
            <li id="logo"><img src="../assets/img/logo.svg"></li>
        </ul>
        <ul>
            <li><a href="./logout.php" class="secondary contrast"><img src="../assets/img/logout.svg"></a></li>
        </ul>
    </nav>

    <article>
        <!-- Mantén el formulario de búsqueda en su lugar -->
        <form id="searchForm">
            <input type="search" name="search" id="searchInput">
        </form>

        <!-- Solo el contenido dentro de #clientsContainer se actualizará con AJAX -->
        <div id="clientsContainer">
            <!-- Contenido generado por AJAX se insertará aquí -->
        </div>

    </article>
    <!-- Mantén el pie de página en su lugar -->
    <footer id="footer">
        <p>Made by Eject Computer Solucions Informatiques S.L. © <?php $year = date("Y"); echo $year; ?></p>
    </footer>
    
    <!-- Importa tus scripts aquí -->
    <script src="../assets/js/modal.js"></script>
    <script src="../assets/js/script.js"></script>

</body>

</html>
