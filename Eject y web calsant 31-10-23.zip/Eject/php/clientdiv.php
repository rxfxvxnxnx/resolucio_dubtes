<?php
require('../database.php');

// Consulta SQL para seleccionar todos los registros de empresas
$queryAll = "SELECT * FROM enterprises";
$resultAll = $con->query($queryAll);

// Verificar si se ha enviado un término de búsqueda
if (isset($_POST['search'])) {
    $searchTerm = $_POST['search'];

    // Consulta SQL para buscar empresas que coincidan con el término de búsqueda
    $query = "SELECT * FROM enterprises 
              WHERE comercialName LIKE ? 
              OR fiscalName LIKE ? 
              OR cif LIKE ? 
              OR tlf LIKE ? 
              OR email LIKE ? 
              OR direction LIKE ?";
   
    if ($stmt = $con->prepare($query)) {
        // Preparar el término de búsqueda para que coincida con cualquier parte del nombre
        $searchTerm = '%' . $searchTerm . '%';

        // Vincular el término de búsqueda a la consulta
        $stmt->bind_param('ssssss', $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm);

        // Ejecutar la consulta
        $stmt->execute();

        // Obtener los resultados
        $result = $stmt->get_result();

        $resultsHTML = '';

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                    $idEnterprise = $row['idEnterprise'];
                    $nombreComercial = $row['comercialName'];
                    $nombreFiscal = $row['fiscalName'];
                    $cif = $row['cif'];
                    $tlf = $row['tlf'];
                    $email = $row['email'];
                    $direccion = $row['direction'];
                
                    $resultsHTML .= '<article id="articleResults'.$idEnterprise.'" data-target="'.$idEnterprise.'">';
                    $resultsHTML .= '<h1>' . htmlspecialchars($nombreComercial, ENT_QUOTES, 'UTF-8') . '</h1>';
                    $resultsHTML .= '<div class="grid">';
                    $resultsHTML .= '<p><strong>Nombre Fiscal: </strong>' . htmlspecialchars($nombreFiscal, ENT_QUOTES, 'UTF-8') . '</p>';
                    $resultsHTML .= '<p><strong>CIF: </strong>' . htmlspecialchars($cif, ENT_QUOTES, 'UTF-8') . '</p>';
                    $resultsHTML .= '</div>';
                    $resultsHTML .= '<div class="grid">';
                    $resultsHTML .= '<p><strong>Tlf: </strong>' . htmlspecialchars($tlf, ENT_QUOTES, 'UTF-8') . '</p>';
                    $resultsHTML .= '<p><strong>Email: </strong>' . htmlspecialchars($email, ENT_QUOTES, 'UTF-8') . '</p>';
                    $resultsHTML .= '</div>';
                    $resultsHTML .= '<p><strong>Dirección: </strong>' . htmlspecialchars($direccion, ENT_QUOTES, 'UTF-8') . '</p>';
                    $resultsHTML .= '<a href="pagina_destino.php">Ver detalles</a>';
                    $resultsHTML .= '</article>';


 
            }
        } else {
            // No se encontraron resultados, muestra un mensaje
            $resultsHTML = '<p class="searchError">No se encontraron resultados que coincidan con la búsqueda...</p>';
        }
        $stmt->close();

        echo $resultsHTML;
    } else {
        echo "Error en la consulta: " . $con->error;
    }
}
?>

